//
//  FPSWindow.swift
//  TintDemo
//
//  Created by Purkylin King on 16/6/1.
//  Copyright © 2016年 Purkylin King. All rights reserved.
//

import UIKit

public enum FpsCalculateMode {
    case Average, Accurate, Range, Default
}

@objc(FPSWindow)
public class FPSWindow: UIWindow {
    var displayLink: CADisplayLink!
    
    var timestamps = [CFTimeInterval]()
    var lastUpdateTime = CFTimeInterval()
    var lastTimestamp = 0.0
    var frameCount = 0
    
    let maxLength = 70
    
    var label = UILabel()
    
    var mode: FpsCalculateMode = .Default // 工作模式
    
    static let shareWindow = FPSWindow()
    
    
    init() {
        super.init(frame: CGRectZero)
        self.rootViewController = UIViewController()
        self.addSubview(label)
        self.displayLink = CADisplayLink(target: self, selector: #selector(displayLinkTick))
        displayLink.addToRunLoop(NSRunLoop.currentRunLoop(), forMode: NSRunLoopCommonModes)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func displayLinkTick() {
        switch self.mode {
        case .Default, .Average:
            averageModeCalculate()
        case .Range:
            rangeModeCalculate()
        default:
            return
        }
    }
    
    func averageModeCalculate() {
        // update timestamps
        if timestamps.count < maxLength {
            if lastTimestamp > 1.0 { // 第一次
                timestamps.append(displayLink.timestamp - lastTimestamp)
            }
        } else {
            // shift left
            for i in 0..<maxLength-1 {
                timestamps[i] = timestamps[i+1]
            }
            timestamps[maxLength - 1] = displayLink.timestamp - lastTimestamp
        }
        
        self.lastTimestamp = displayLink.timestamp
        
        if (displayLink.timestamp - lastUpdateTime > 1) && timestamps.count >= 60{
            let avg = timestamps.reduce(0.0, combine: +) / Double(timestamps.count)
            let frame = Int(1.0 / avg)
            print("avg frame: \(Int(floor(1.0 / avg)))")
            label.text = "frame: \(frame)"
            label.center.x = self.center.x
            label.backgroundColor = UIColor.whiteColor()
            label.sizeToFit()
            lastUpdateTime = displayLink.timestamp
        }
    }
    
    func rangeModeCalculate() {
        frameCount += 1
    }
    
    public func stop() {
        self.displayLink.paused = true
        let interval = NSDate().timeIntervalSince1970 - lastUpdateTime
        let frameRate = Int(ceil(Double(frameCount) / interval))
        print("interval: \(interval), total: \(frameCount), avg: \(frameRate)")
        label.text = "frame: \(frameRate )"
        label.center.x = self.center.x
        label.sizeToFit()
    }
    
    public func start() {
        label.text = "Calculate---"
        label.center.x = self.center.x
        label.sizeToFit()
        frameCount = 0
        self.lastUpdateTime = NSDate().timeIntervalSince1970
        self.displayLink.paused = false
    }
    
    public func toggle() {
        if self.displayLink.paused {
            start()
        } else {
            stop()
        }
    }
    
    deinit {
        displayLink.invalidate()
    }
    
    public func show(mode: FpsCalculateMode = .Default) {
        self.mode = mode
        let frame = UIScreen.mainScreen().bounds
        self.frame = CGRectMake(0, 0, frame.size.width, 22)
        self.windowLevel = UIWindowLevelAlert
        self.makeKeyAndVisible()
        
        if mode == .Range {
            self.displayLink.paused = true
        }
    }
}
